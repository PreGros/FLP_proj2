pole1 = ['AB', 'CA']

pole1 = [''.join(sorted(elem)) for elem in pole1]

for elem in pole1:
    print(elem)